#ifndef SHELL_SORT_H
#define SHELL_SORT_H

#include "lista_encadeada.h"

extern int trocas;
extern int comparacoes;

void shellSortLista(Node *head);

#endif
